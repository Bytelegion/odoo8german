Some of the brilliant feature of the module:
--------------------------------------------

1. synchronise all the catalog categories to Magento.

2. synchronise all the catalog products to Magento.

3. synchronise all the existing sales order(Invoice, shipping) to Magento.

4. Update all the store customers to Magento.

5. synchronise product inventory of catelog products.