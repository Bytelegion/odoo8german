# -*- coding: utf-8 -*-
##############################################################################
#
#   OpenERP, Open Source Management Solution
#    Copyright (C) 2013 webkul
#	 Author :
#				www.webkul.com	
#
##############################################################################
import mob
import res_config
import core_overrides
import bridge_backbone
import wizard
import mob_synchronization


# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
